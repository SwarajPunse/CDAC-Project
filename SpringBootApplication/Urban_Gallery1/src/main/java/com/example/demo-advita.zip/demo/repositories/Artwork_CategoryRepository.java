package com.example.demo.repositories;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Artwork_Category;

@Transactional
@Repository
public interface Artwork_CategoryRepository extends JpaRepository <Artwork_Category, Integer>{
	
	@Query("select a from Artwork_Category a where a.id = :acid and a.cname = :cname")
	public Optional<Artwork_Category> getCategory(String acid,String cname);

}
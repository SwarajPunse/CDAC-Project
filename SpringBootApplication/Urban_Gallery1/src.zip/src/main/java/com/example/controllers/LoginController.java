package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Login;
import com.example.entities.LoginCheck;
import com.example.services.LoginService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class LoginController {
	
	@Autowired
	LoginService lservice;
	
	@PostMapping("/checkLogin")
	public Login checkLogin(@RequestBody LoginCheck lcheck)
	{
		return lservice.getLogin(lcheck.getUsername(), lcheck.getPassword());
	}

}

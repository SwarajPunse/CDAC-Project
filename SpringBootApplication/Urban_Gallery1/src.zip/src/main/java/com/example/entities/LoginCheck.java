package com.example.entities;

public class LoginCheck {
	String username,password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String uid) {
		this.username = uid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String pwd) {
		this.password = pwd;
	}

}

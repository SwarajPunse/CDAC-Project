package com.example.entities;

public class Artwork {

	
	

}

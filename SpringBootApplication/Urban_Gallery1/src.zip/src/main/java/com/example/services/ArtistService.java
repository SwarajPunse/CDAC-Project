package com.example.services;

public class ArtistService {

}

package com.example.repositories;

public interface ArtistRepository {

}

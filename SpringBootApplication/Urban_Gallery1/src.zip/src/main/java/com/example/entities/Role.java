package com.example.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="roles")
public class Role {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int rid;
	
	@Column
	String role;
	
	@JsonIgnoreProperties("roles")
	@OneToMany(mappedBy="roles",cascade = CascadeType.ALL)	
	Set<Login> logins;

	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Role(int rid, String role, Set<Login> logins) {
		super();
		this.rid = rid;
		this.role = role;
		this.logins = logins;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set<Login> getLogins() {
		return logins;
	}

	public void setLogins(Set<Login> logins) {
		this.logins = logins;
	}

	@Override
	public String toString() {
		return "Role [rid=" + rid + ", role=" + role + ", logins=" + logins + "]";
	}
	
	

}
